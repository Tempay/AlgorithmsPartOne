import edu.princeton.cs.algs4.StdRandom;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Created by Tempa on 12/9/2016.
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

    private Node first;
    private int size;

    private class Node {
        Item item;
        Node next;
    }

    public RandomizedQueue() {
        this.first = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void enqueue(Item item) {
        Node newFirst = new Node();
        newFirst.item = item;
        newFirst.next = first;
        first = newFirst;
        size++;
    }

    public Item dequeue() {
        int random = StdRandom.uniform(size);
        Node removedNode = first;
        while (random-- > 1) {
            removedNode = removedNode.next;
        }
        Item item = removedNode.next.item;
        removedNode.next = removedNode.next.next;
        size--;
        return item;
    }

    public Iterator<Item> iterator() {
        Iterator<Item> iterator = new Iterator<Item>() {
            Node cur = first;
            @Override
            public boolean hasNext() {
                return cur.next != null;
            }

            @Override
            public Item next() {
                if (cur.next == null) {
                    throw new NoSuchElementException();
                }
                cur = cur.next;
                return cur.item;
            }
        };
        return iterator;
    }

    public Item sample() {
        int random = StdRandom.uniform(size);
        Node sample = first;
        while (random-- > 0) {
            sample = sample.next;
        }
        return sample.item;
    }

    public static void main(String[] args) {
    }
}
